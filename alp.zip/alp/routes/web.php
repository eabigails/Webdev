<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('home');
})->name('home');

Route::get('/fashion', function () {
    return view('fashion');
})->name('fashion');

Route::get('/cart', function () {
    return view('cart');
})->name('cart');
