<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Head content including CSS links and title -->
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>Queen of</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <!-- style css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
    <!-- Responsive -->
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">
    <!-- fevicon -->
    <link rel="icon" href="<?php echo e(asset('images/fevicon.png')); ?>" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.mCustomScrollbar.min.css')); ?>">
    <!-- Tweaks for older IEs -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.css')); ?>">
    <!-- fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <!-- font awesome -->
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- owl stylesheets -->
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes|Poppins:400,700&display=swap&subset=latin-ext" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
    
    <style>
        .left{
            padding-right: 50px;
        }
    </style>
</head>
<body>
    <!-- Your header section -->
    
    <!-- Cart Section Start -->
    <div class="container">
        <h1 class="fashion_taital">Shopping Cart</h1>
        <div id="cart-items">
            <!-- Cart items will be displayed here -->
            
        </div>
        <div id="cart-total">
            <!-- Cart total will be displayed here -->
        </div>
        
    </div>
    <!-- Cart Section End -->

    <script>
        function loadCart() {
            // Load cart items from local storage
            let cart = JSON.parse(localStorage.getItem('cart')) || [];

            let cartItemsContainer = document.getElementById('cart-items');
            let cartTotalContainer = document.getElementById('cart-total');

            if (cart.length === 0) {
                cartItemsContainer.innerHTML = '<p>Your cart is empty.</p>';
                cartTotalContainer.innerHTML = '';
                return;
            }

            let cartItemsHTML = '';
            let totalPrice = 0;

            // Perulangan untuk membuat elemen-elemen keranjang
            cart.forEach(item => {
                cartItemsHTML += `
                    <div class="cart">
                        <img src="${item.image}" alt="${item.name}" width="100">
                        <div>
                            
                            <h4>${item.name}</h4>
                            <p class="Left">Price: $${item.price}</p>
                            <p class="Left">Quantity: ${item.quantity}</p>
                            <button class="mt-2" onclick="removeFromCart('${item.name}')">X</button>
                           
                        </div>
                        <hr>
                    </div>
                `;
                // Menambahkan harga produk kali jumlahnya ke total harga
                totalPrice += item.price * item.quantity;
                
            });

            cartItemsContainer.innerHTML = cartItemsHTML;
            cartTotalContainer.innerHTML = `<h3>Total Price: $${totalPrice.toFixed(2)}</h3>`;
        }

        function removeFromCart(itemName) {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];

            // Find the index of the item in the cart
            let itemIndex = cart.findIndex(item => item.name === itemName);
            if (itemIndex > -1) {
                // Remove the item from the cart array
                cart.splice(itemIndex, 1);
                // Save the updated cart back to local storage
                localStorage.setItem('cart', JSON.stringify(cart));
                // Reload the cart to reflect the changes
                loadCart();
            }
        }

        // Load the cart when the page is loaded
        window.onload = loadCart;
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\alp\resources\views/cart.blade.php ENDPATH**/ ?>